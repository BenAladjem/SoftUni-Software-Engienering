from project.motorcycle import Motorcycle

class cross_motorcycle(Motorcycle):
    def __init__(self, fuel, horse_pover):
        super().__init__(fuel, horse_pover)